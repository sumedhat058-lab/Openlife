# Contributing

For a demo change, keep the project mobile-friendly and accessible. Test on a phone-sized screen. Never commit secrets or real user data.
