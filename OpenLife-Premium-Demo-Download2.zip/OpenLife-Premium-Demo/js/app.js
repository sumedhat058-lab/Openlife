const note = document.getElementById('note');
const noteStatus = document.getElementById('noteStatus');
try { note.value = localStorage.getItem('openlife-demo-note') || ''; } catch(e) {}
document.getElementById('saveNote').addEventListener('click', () => {
  try { localStorage.setItem('openlife-demo-note', note.value); noteStatus.textContent = 'සටහන මේ browser එකේ සුරැකුවා.'; }
  catch(e) { noteStatus.textContent = 'සුරැකීමට browser storage අවසර අවශ්‍යයි.'; }
});
document.getElementById('clearNote').addEventListener('click', () => {
  note.value = '';
  try { localStorage.removeItem('openlife-demo-note'); } catch(e) {}
  noteStatus.textContent = 'සටහන මකා දැමුවා.';
});
const wordText = document.getElementById('wordText');
function updateCounts() {
  const value = wordText.value.trim();
  document.getElementById('wordCount').textContent = value ? value.split(/\s+/).length : 0;
  document.getElementById('charCount').textContent = wordText.value.length;
}
wordText.addEventListener('input', updateCounts);
document.getElementById('themeBtn').addEventListener('click', () => document.body.classList.toggle('light'));
document.getElementById('freeBtn').addEventListener('click', () => alert('ඔබට Free demo එක භාවිතා කළ හැකියි.'));
document.getElementById('premiumBtn').addEventListener('click', () => alert('Premium තවම සකස් කරමින් පවතී. මෙය demo එකක් පමණයි.'));
