# Security notes

- This static demo does not process payments or verify subscriptions.
- Do not put API keys, passwords, payment secrets, or private credentials in HTML/JavaScript or a public repository.
- A real Premium service must verify payment/subscription status on a trusted server and validate provider webhooks.
- Add authentication, authorization, server-side rate limits, abuse protection, and database access policies before production.
- Do not collect sensitive user information in this demo.
