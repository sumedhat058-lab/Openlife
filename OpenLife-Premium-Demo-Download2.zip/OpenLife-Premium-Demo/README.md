# OpenLife Premium Demo

Mobile-friendly static prototype with a black/red design.

## Run locally
Open `index.html` in a browser. For best results, keep the `css` and `js` folders next to `index.html`.

## Publish with GitHub Pages
1. Create a public GitHub repository named `OpenLife`.
2. Upload the contents of this folder to the repository root (not the enclosing folder).
3. In repository Settings → Pages, choose **Deploy from a branch**, select `main` and `/(root)`, then Save.

## Important
This is only a frontend demo. It has no real user accounts, AI backend, payments, or subscriptions. Notes are stored locally in the browser. Do not treat local browser data as proof of payment. Production requires a secure backend, database, authentication, payment-provider verification, and server-side secret storage.
